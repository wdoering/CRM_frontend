## Omnisharp for VS Code

Don't install this extension unless you want to try an early version. By default it is already
bundled with VS Code.

### Development

To **run and develop** do the following:

* run `npm i`
* open in VS Code
* *(opt)* run `tsc -w`, make code changes
* hit F5

